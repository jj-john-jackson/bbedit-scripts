<!-- -*- coding: utf-8; mode: markdown; version: 1; -*- -->

About the BBEdit pyscripts (pyscripts-v0.6)
--------------------------------

This package ("pyscripts-v0.6.bbpackage") contains scripts which extend BBEdit’s capabilities.
They are a collection of scripts that perform common tasks helpful when writing in RST or
Markdown. They also demonstrate techniques that can be used to extend BBEdit to
perform almost anything you might require.

(This document is written in [Markdown](http://www.daringfireball.net/projects/markdown/).
It's readable as plain text, but prettier if you choose "Preview in BBEdit" from
the "Markup" menu.)

To install the scripts, copy the package "pyscripts-v0.6.bbpackage" to your application's "Application
Support/BBEdit/Packages" folder, creating the "Packages" folder if necessary. The
installation script ("install.sh") will copy it to your iCloud drive, making it
available for all copies of BBEdit that you use.

You can add a keyboard shortcut for any of the scripts; in BBEdit’s
"Preferences -> Menus & Shortcuts", select "Scripts" from the left list, select a script
in the right pane, and then click the existing key combination shown (or the placeholder
text "none") and enter your desired combination.

Below is a description of each script:

- **Bold**

  Surrounds the selection with double-asterisks (**)


- **Brace**

  Surrounds the selection in curved braces ({ })


- **Build Table Markdown**

  Formats (pretty-prints) a table written in Markdown-format


- **Build Table RST**

  Formats (pretty-prints) a table written in RST-format


- **Case Lower**

  Changes the selection to lowercase


- **Case Upper**

  Changes the selection to uppercase


- **CSS**

  Reformats using BBEdit CSS rules


- **Delete Left**

  Deletes the left-most character of each line


- **Double Quotes**

  Surrounds the selection in double-quotes ("")


- **Emphasize**

  Surrounds the selection with asterisks (*)


- **Escape Backslashes**

  Escapes any backslashes in the selection


- **Glossary**

  No description available.


- **Insert Today's Date**

  Inserts today's date at the insertion point or replaces selection


- **Literal**

  Surrounds the selection in double back-ticks (``)


- **Markdown Literal**

  Surrounds the selection in single back-ticks (`)


- **Over and Underlines**

  Inserts lines of characters (first character of second line, same length) before and after the first line.
  If there are more than three lines, tries to determine if first two or three lines are an existing title or not.


- **Replace Hyphens**

  Replaces hyphens (-) with underscores (_)


- **Replace Spaces**

  Replaces spaces ( ) with hyphens (-)


- **Replace with Hyphens**

  Replaces spaces ( ) and underscores (_) with hyphens (-)


- **RST Comment**

  Toggles selection with leading RST comment markers (..)


- **Search with DuckDuckGo**

  Searches for the selection using DuckDuckGo and the default browser


- **Shift Left**

  Deletes the left-most character of each line, if a space character


- **Shift Right**

  Adds a leading space character to each line


- **Single Quotes**

  Surrounds the selection in single-quotes (')


- **Strip**

  Removes the leading and trailing characters if they match


- **Swap Quotes**

  Swaps single-quotes for double-quotes and vice-versa


- **Underline**

  Inserts a line of characters (first character of second line, same length) after the first line


- **Wrap**

  Wraps and indents lines if first character of a line is a hyphen or asterisk



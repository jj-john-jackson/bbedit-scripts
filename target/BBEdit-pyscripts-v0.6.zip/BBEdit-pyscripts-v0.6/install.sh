#!/bin/bash
mkdir -p ~/Library/Mobile\ Documents/com~apple~CloudDocs/Application\ Support/BBEdit/Packages/
rm -f
cp -R pyscripts-v0.6.bbpackage ~/Library/Mobile\ Documents/com~apple~CloudDocs/Application\ Support/BBEdit/Packages/

